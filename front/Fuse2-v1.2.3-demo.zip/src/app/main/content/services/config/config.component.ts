import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-config-service-docs',
    templateUrl: './config.component.html',
    styleUrls  : ['./config.component.scss']
})
export class FuseConfigServiceDocsComponent
{
    constructor()
    {

    }
}
