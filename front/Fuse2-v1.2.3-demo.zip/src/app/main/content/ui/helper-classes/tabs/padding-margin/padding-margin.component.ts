import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-helper-classes-padding-margin',
    templateUrl: './padding-margin.component.html',
    styleUrls  : ['./padding-margin.component.scss']
})
export class FuseHelperClassesPaddingMarginComponent
{

    constructor()
    {

    }
}
