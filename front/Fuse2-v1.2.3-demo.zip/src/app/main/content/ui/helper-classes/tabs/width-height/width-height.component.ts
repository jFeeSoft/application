import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-helper-classes-width-height',
    templateUrl: './width-height.component.html',
    styleUrls  : ['./width-height.component.scss']
})
export class FuseHelperClassesWidthHeightComponent
{

    constructor()
    {

    }
}
