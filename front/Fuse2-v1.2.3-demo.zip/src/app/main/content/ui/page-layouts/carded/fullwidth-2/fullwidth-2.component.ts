import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-carded-fullwidth-2',
    templateUrl: './fullwidth-2.component.html',
    styleUrls  : ['./fullwidth-2.component.scss']
})
export class FuseCardedFullWidth2Component
{
    constructor()
    {
    }
}
