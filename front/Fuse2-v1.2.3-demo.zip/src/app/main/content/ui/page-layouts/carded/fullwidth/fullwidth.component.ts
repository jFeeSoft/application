import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-carded-fullwidth',
    templateUrl: './fullwidth.component.html',
    styleUrls  : ['./fullwidth.component.scss']
})
export class FuseCardedFullWidthComponent
{
    constructor()
    {
    }
}
