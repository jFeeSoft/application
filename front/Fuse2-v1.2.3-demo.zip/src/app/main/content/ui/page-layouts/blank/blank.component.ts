import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-blank',
    templateUrl: './blank.component.html',
    styleUrls  : ['./blank.component.scss']
})
export class FuseBlankComponent
{
    constructor()
    {
    }
}
