import { Component, OnInit } from '@angular/core';

@Component({
    selector   : 'fuse-search',
    templateUrl: './search.component.html',
    styleUrls  : ['./search.component.scss']
})
export class FuseSearchComponent implements OnInit
{

    constructor()
    {

    }

    ngOnInit()
    {

    }
}
