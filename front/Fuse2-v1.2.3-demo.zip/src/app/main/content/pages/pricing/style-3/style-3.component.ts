import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-pricing-style-3',
    templateUrl: './style-3.component.html',
    styleUrls  : ['./style-3.component.scss']
})
export class FusePricingStyle3Component
{
    constructor()
    {

    }

}
