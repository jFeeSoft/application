import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-hljs-docs',
    templateUrl: './hljs.component.html',
    styleUrls  : ['./hljs.component.scss']
})
export class FuseHljsDocsComponent
{
    constructor()
    {

    }
}
