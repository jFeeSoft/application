import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-shortcuts-docs',
    templateUrl: './shortcuts.component.html',
    styleUrls  : ['./shortcuts.component.scss']
})
export class FuseShortcutsDocsComponent
{
    constructor()
    {

    }
}
